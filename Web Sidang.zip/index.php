<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>SIDANG | Sistem Informasi data Perpustakaan Pengadilan Negeri Banyuwangi</title>

        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/logopn.png" />

        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />

    </head>
    <body>

        <!-- Responsive navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-success">
            <div class="container px-lg-5">
                <a class="navbar-brand" href="#">
                    <img src="assets/img/logopn.png" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                    SIDANG
                </a>
            </div>
        </nav>

        <!-- Header-->
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="assets/img/gambar1.png" class="d-block w-100" alt="gambar 1">
                    <div class="carousel-caption d-none d-md-block">
                        <h5></h5>
                        <p></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="assets/img/gambar2.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5></h5>
                        <p></p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="assets/img/gambar3.png" class="d-block w-100" alt="...">
                    <div class="carousel-caption d-none d-md-block">
                        <h5></h5>
                        <p></p>
                    </div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <!-- Page Content-->
        <section class="pt-5">
            <div class="container px-lg-5">
                <!-- Page Features-->
                <div class="row gx-lg-5">


                    <!-- Hukum Acara Perdata -->
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div><br>
                                <a href="https://drive.google.com/drive/folders/1cXAMWuMeVUn5-4c9kvC_5rxR9XZK417H" class="btn btn-success stretched-link">Hukum Acara Perdata</a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hukum Acara Pidana -->
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div><br>
                                <a href="https://drive.google.com/drive/folders/1yh6jVy6hQr5KppS4UTX3luCmJER7VK1p" class="btn btn-success stretched-link">Hukum Acara Pidana</a>
                            </div>
                        </div>
                    </div>

                    <!-- Hukum Perdata -->
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div><br>
                                <a href="https://drive.google.com/drive/folders/1MObdoY9zs3lyLMHLH4XCt7I0ih1VV-Qq" class="btn btn-success stretched-link">Hukum Perdata</a>
                            </div>
                        </div>
                    </div>

                    <!-- Hukum Pidana -->
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div><br>
                                <a href="https://drive.google.com/drive/folders/1xsMQ2nT0zlej3sNjp0XaeWRL96iFZ3lp" class="btn btn-success stretched-link">Hukum Pidana</a>
                            </div>
                        </div>
                    </div>


                    <!-- Majalah Pengadilan -->
                    <div class="col-lg-6 col-xxl-4 mb-5">
                        <div class="card bg-light border-0 h-100">
                            <div class="card-body text-center p-4 p-lg-5 pt-0 pt-lg-0">
                                <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-n4"><i class="bi bi-collection"></i></div><br>
                                <a href="https://drive.google.com/drive/folders/1SXCPp9mYEM_fmegOfVbYPybZOtOsJRy7" class="btn btn-success stretched-link" id="aaa">Majalah Pengadilan</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- Footer-->
        <footer class="py-1 bg-success">
            <div class="container">
                <p class="m-0 text-center text-white">
                    Copyright &copy; Pengadilan Negeri Banyuwangi
                </p>
            </div>
        </footer>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

        <!-- Text to Speech -->
        <script src="https://code.responsivevoice.org/responsivevoice.js?key=dob0PxZ2"></script>
        
        <!-- navigation -->
        <script>(function(d){var s = d.createElement("script");s.setAttribute("data-account", "3ETbX6ewEK");s.setAttribute("src", "https://cdn.userway.org/widget.js");(d.body || d.head).appendChild(s);})(document)</script><noscript>Please ensure Javascript is enabled for purposes of <a href="https://userway.org">website accessibility</a></noscript>
    </body>
</html>
